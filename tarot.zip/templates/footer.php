<script src="script.js"></script>
</body>
</html>
