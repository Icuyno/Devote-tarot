<nav>
<div class="mobile_nav">
    <div id="menu_btn">
        <div class="open_menu">
            Menu
        </div>
        <svg class="icon icon-close" xmlns="http://www.w3.org/2000/svg" width="34" height="34" viewBox="0 0 34 34" fill="none">
            <path d="M1 33L33 1M1 1L33 33" stroke="#55200C" stroke-width="3" stroke-linecap="round"/>
        </svg>
    </div>
</div>

<div class="mobile_menu_container">
    <div class="mobile_menu">
        <ul>
            <li>
                <a href="index.php">
                    Home
                </a>
            </li>
            <li>
                <a href="rules.php">
                    Rules
                </a>
            </li>
            <li>
                <a href="tarot.php">
                    Tarot
                </a>
            </li>
        </ul>
    </div>
</div>
</nav>


